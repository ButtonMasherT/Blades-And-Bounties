﻿public class AILocomotionBase
{
}