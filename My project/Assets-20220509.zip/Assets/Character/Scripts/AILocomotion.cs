using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class AILocomotion : MonoBehaviour
{
    public float maxTime = 1.0f;
    public float maxDistance = 1.0f;
    Animator animator;
    NavMeshAgent agent;
    public Transform PlayerTransform;
    float timer = 0.0f;
   
    AILocomotion aI;

    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
      
        aI = GetComponent<AILocomotion>();
      
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime; 
        if (timer < 0.0f)
            {
                float sqDistance = (PlayerTransform.position - agent.destination).sqrMagnitude;

                if (sqDistance > maxDistance * maxDistance)
                {
                    agent.destination = PlayerTransform.position;
                }
                timer = maxTime;
          }    
            animator.SetFloat("Speed", agent.velocity.magnitude);
         
      
    }
    public void Disable()
    {
        aI.enabled = false;
        
    }

}