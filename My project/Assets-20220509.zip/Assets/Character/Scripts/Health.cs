using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    
    UIHealthBar healthBar;
    public float maxHealth;
    [HideInInspector]
    public float currentHealth;
    Ragdoll ragdoll;
    SkinnedMeshRenderer skinnedMeshRenderer;
   AILocomotion aI;
    // Start is called before the first frame update
    void Start()
    {
        ragdoll = GetComponent<Ragdoll>();
        currentHealth = maxHealth;
        skinnedMeshRenderer = GetComponentInChildren<SkinnedMeshRenderer>();
        aI = GetComponent<AILocomotion>();
        healthBar = GetComponentInChildren<UIHealthBar>();
        var rigidBodies = GetComponentsInChildren<Rigidbody>(); 
        foreach(var rigidBody in rigidBodies) {
           HitBox hitBox = rigidBody.gameObject.AddComponent<HitBox>();
            hitBox.health = this;
                
        }
    }
    public void TakeDamage(float amount) {
        currentHealth -= amount;
        healthBar.SetHealthBarPercentage(currentHealth / maxHealth);
        if (currentHealth <= 0.0f)
        {
            Die();
        }

      
    }

    private void Die()
    {
        ragdoll.ActivateRagdoll();
       aI.Disable();
          healthBar.gameObject.SetActive(false);
    }

    
}
