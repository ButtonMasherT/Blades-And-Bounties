
February 23, 2018

Thanks for downloading this asset.



Demo Scene
----------
For better enjoy of the demo scene you should add some Unity Assets dependencies like:
- Character Controller
- Effects
- Post Processing


Models
------
Included are the source for the models as .fbx files


Materials
---------
Included are a set of sample materials which can easily changed.
The models intended to be flat so there is no texture.


Doors
-----
Included is a script to open and closing doors when the character get close to it.


Door Sound FX
-------------
Tnanks to https://www.freesoundeffects.com/ for this great free sounds.


Lights
------
Included is a script to make lights flickers.
This scripts expects an Unity Light element as children of the model.

There are several material for lights but can easily add new ones.

